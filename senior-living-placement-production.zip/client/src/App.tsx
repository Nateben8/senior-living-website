import React from 'react'
import { Route, Switch } from 'wouter'
import { Toaster } from '@/components/ui/toaster'
import { Header } from '@/components/Header'
import { Footer } from '@/components/Footer'
import { HomePage } from '@/pages/HomePage'
import { AboutPage } from '@/pages/AboutPage'
import { ContactPage } from '@/pages/ContactPage'
import { BlogPage } from '@/pages/BlogPage'
import { FacilitiesPage } from '@/pages/FacilitiesPage'
import { AssessmentPage } from '@/pages/AssessmentPage'
import { LandingPage } from '@/pages/LandingPage'

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/about" component={AboutPage} />
          <Route path="/contact" component={ContactPage} />
          <Route path="/blog" component={BlogPage} />
          <Route path="/facilities" component={FacilitiesPage} />
          <Route path="/assessment" component={AssessmentPage} />
          <Route path="/landing" component={LandingPage} />
        </Switch>
      </main>
      <Footer />
      <Toaster />
    </div>
  )
}

export default App 